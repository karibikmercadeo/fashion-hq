# Fashion HQ Dashboard

Dashboard centralizado de marketing para directora de moda.

## Secciones
- ⚡ Resumen general
- 🛍️ Tienda Online (Shopify)
- 💜 CRM / WooUp
- ✨ Influencers
- 📱 Contenido Orgánico
- 📅 Calendario Editorial

## Cómo correr localmente
```bash
npm install
npm start
```

## Cómo deployar en Vercel
1. Subir este repositorio a GitHub
2. Conectar el repo en vercel.com
3. Click en Deploy — listo ✅
